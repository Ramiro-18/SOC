class ArraySorter:
    def __init__(self):
        self.array = [5]

    def get_array(self, length):
        self.array = [5]
        for i in range(length):
            element = input(f"Enter element {i+1}: ")
            self.array.append(element)
        self.array.sort()
        return self.array