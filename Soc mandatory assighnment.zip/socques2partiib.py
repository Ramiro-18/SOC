import numpy as np

random_matrix = np.random.uniform(low=0.0, high=1.0, size=(4, 4))

print(random_matrix)
