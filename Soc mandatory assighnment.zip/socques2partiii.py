import pandas as pd
import numpy as np

df = pd.read_csv(r"C:\Users\Jayesh\Downloads\Data - STOCK_US_XNYS_CSV.csv")

df['date'] = pd.to_datetime(df['Date'])

df.set_index('date', inplace=True)

monthly_closing_avg = df.resample('M')['Close'].mean()

print(monthly_closing_avg)
