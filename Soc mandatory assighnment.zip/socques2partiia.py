import numpy as np

matrix = [[1, 2, 3, 4],
          [5, 6, 7, 8],
          [9, 10, 11, 12],
          [13, 14, 15, 16]]

matrix_np = np.array(matrix)

diagonal = np.diag(matrix_np)
print("Diagonal elements:", diagonal)

trace = np.trace(matrix_np)
print("Trace of the matrix:", trace)

max_row = np.max(matrix_np, axis=1)
min_row = np.min(matrix_np, axis=1)
print("Max element of each row:", max_row)
print("Min element of each row:", min_row)
