def compute_cost(years_experience, salary, w, b):
    """
    Computes the cost function J for linear regression.
    
    Arguments:
    years_experience -- list or array of years of experience
    salary -- list or array of corresponding salaries
    w -- slope of the linear regression line
    b -- intercept of the linear regression line
    
    Returns:
    cost -- total cost of the linear regression model
    """
def compute_gradient(years_experience, salary, w, b):
    """
    Computes the gradients dJ/dw and dJ/db for linear regression.
    
    Arguments:
    years_experience -- list or array of years of experience
    salary -- list or array of corresponding salaries
    w -- slope of the linear regression line
    b -- intercept of the linear regression line
    
    Returns:
    dw -- gradient of the cost function with respect to w
    db -- gradient of the cost function with respect to b
    """
def compute_gradient_descent(x_train, y_train, w_init=0, b_init=0, alpha=0.01, num_iters=10000):
    m = len(x_train)  # number of training examples
    
    for _ in range(num_iters):
        # Compute predictions
        y_pred = w_init * x_train + b_init
        
        # Compute cost
        cost = compute_cost(y_train, y_pred)
        
        # Compute gradients
        dw = compute_gradient(x_train, y_train, y_pred)
        db = dw  # assuming simple linear regression
        
        # Update parameters
        w_init -= alpha * dw
        b_init -= alpha * db
    
    return w_init, b_init
