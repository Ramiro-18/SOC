import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# Load the dataset
train_data = pd.read_csv('train.csv')
test_data = pd.read_csv('test.csv')

# Combine train and test data for preprocessing
combined_data = pd.concat([train_data, test_data], axis=0)

# Encode categorical features
cat_cols = ['product_code']
for col in cat_cols:
    label_encoder = LabelEncoder()
    combined_data[col] = label_encoder.fit_transform(combined_data[col].astype(str))

# Split the combined data back into train and test sets
train_data = combined_data[:len(train_data)]
test_data = combined_data[len(train_data):]

# Separate features and target variable
X_train = train_data.drop('failure', axis=1)
y_train = train_data['failure']
X_test = test_data.drop('failure', axis=1)

# Train a Random Forest Classifier
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Make predictions on the test data
predictions = model.predict(X_test)

# Create a submission file with product IDs and corresponding failure predictions
submission_df = pd.DataFrame({'id': test_data['id'], 'failure': predictions})

# Save the submission file
submission_df.to_csv('predictions.csv', index=False)
