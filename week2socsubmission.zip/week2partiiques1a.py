import matplotlib.pyplot as plt

# Dataset
years_experience = [1, 3, 5]
salary = [300, 480, 570]

# Scatter plot
plt.scatter(years_experience, salary)
plt.xlabel('Years of Experience')
plt.ylabel('Salary')
plt.title('Years of Experience vs Salary')

# Linear regression line
w = 200
b = 100
x = range(0, 6)
y = [w * i + b for i in x]
plt.plot(x, y, color='red')

# Display the plot
plt.show()
