def compute_cost(years_experience, salary, w, b):
    """
    Computes the cost function J for linear regression.
    
    Arguments:
    years_experience -- list or array of years of experience
    salary -- list or array of corresponding salaries
    w -- slope of the linear regression line
    b -- intercept of the linear regression line
    
    Returns:
    cost -- total cost of the linear regression model
    """
    m = len(years_experience)  # number of data points
    total_cost = 0
    
    for i in range(m):
        # Predicted salary using the linear regression line
        predicted_salary = w * years_experience[i] + b
        
        # Difference between predicted and actual salary
        error = predicted_salary - salary[i]
        
        # Squared error
        squared_error = error ** 2
        
        # Accumulate the squared errors
        total_cost += squared_error
    
    # Mean squared error
    cost = total_cost / (2 * m)
    
    return cost

# Example usage
years_experience = [1, 3, 5]
salary = [300, 480, 570]
w = 200
b = 100

cost = compute_cost(years_experience, salary, w, b)
print("Total cost:", cost)
