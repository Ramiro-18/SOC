def compute_gradient(years_experience, salary, w, b):
    """
    Computes the gradients dJ/dw and dJ/db for linear regression.
    
    Arguments:
    years_experience -- list or array of years of experience
    salary -- list or array of corresponding salaries
    w -- slope of the linear regression line
    b -- intercept of the linear regression line
    
    Returns:
    dw -- gradient of the cost function with respect to w
    db -- gradient of the cost function with respect to b
    """
    m = len(years_experience)  # number of data points
    dw = 0
    db = 0
    
    for i in range(m):
        # Predicted salary using the linear regression line
        predicted_salary = w * years_experience[i] + b
        
        # Difference between predicted and actual salary
        error = predicted_salary - salary[i]
        
        # Update gradients
        dw += error * years_experience[i]
        db += error
    
    # Scale the gradients by 1/m
    dw /= m
    db /= m
    
    return dw, db

# Example usage
years_experience = [1, 3, 5]
salary = [300, 480, 570]
w = 200
b = 100

dw, db = compute_gradient(years_experience, salary, w, b)
print("Gradient dw:", dw)
print("Gradient db:", db)
